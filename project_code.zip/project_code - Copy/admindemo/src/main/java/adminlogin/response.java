package adminlogin;

import jakarta.servlet.RequestDispatcher;
import java.awt.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.beans.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

/**
 * Servlet implementation class response
 */
public class response extends HttpServlet  {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public response() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub

		RequestDispatcher dispatcher=null ;
		PrintWriter out=response.getWriter();
		Connection con;
		Statement smt;
		String ctype;
		String complaint;

	   /* String head[]= {"c_type","dis"};
	    String data[][];
	    int i;*/
		response.setContentType("text/html");
		
		 try {
				
				
				Class.forName("com.mysql.jdbc.Driver");
				String connectionURL = "jdbc:mysql://localhost:3306/student?useSSL=false";
				System.out.println("getConnection START");
				
		        con = DriverManager.getConnection(connectionURL, "root", "Tanu@123");
		        System.out.println(con);
		        System.out.println("getConnection END");
		        
		        PreparedStatement pst = con.prepareStatement("select * from complaint where C_type=? and c_dis=?");
		        //smt= (Statement) con.createStatement();

		       // pst.setString(1,ctype);	
				//pst.setString(2,complaint);
				
				ResultSet rst=pst.executeQuery("select * from complaint");
				out.println("<!DOCTYPE html>\n"
						+ "<html>\n"
						+ "<head>\n"
						+ "  <meta charset=\"utf-8\">\n"
						+ "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
						+ "  <title></title>\n"
						+ "  <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ\" crossorigin=\"anonymous\">\n"
						+ "</head>\n"
						+ "<body>\n"
						+ "<table class=\"table table-bordered\">\n"
						+ "  <thead>\n"
						+ "    <tr>\n"
						+ "      \n"
						+ "      <th scope=\"col\" style=\"width: 50%;\">Complaint</th>\n"
						+ "      <th scope=\"col\" style=\"width: 50%;\">Discription</th>\n"
						+ "      \n"
						+ "    </tr>\n"
						+ "  </thead>\n"
						+ "</table>\n"
						+ "<script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js\" integrity=\"sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe\" crossorigin=\"anonymous\"></script>\n"
						+ "</body>\n"
						+ "</html>\n"
						+ "");
				while(rst.next())
				{
					ctype=rst.getString(1);
					 complaint=rst.getString(2);
					 out.println("<!DOCTYPE html>\n"
					 		+ "<html>\n"
					 		+ "<head>\n"
					 		+ "  <meta charset=\"utf-8\">\n"
					 		+ "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
					 		+ "  <title></title>\n"
					 		+ "  <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ\" crossorigin=\"anonymous\">\n"
					 		+ "</head>\n"
					 		+ "<body>\n"
					 		+ "<table class=\"table table-bordered\">\n"
					 	
					 		+ "  <tbody>\n"
					 		+ "    <tr>\n"
					 		+ "      \n"
					 		+ "      <td scope=\"row\" style=\"width: 50%;\">"+rst.getString(1)+"</td>\n"
					 		+ "      <td style=\"width: 50%;\">"+rst.getString(2)+"</td>\n"
					 		+ "      \n"
					 		+ "    </tr>\n"
					 		+ "    \n"
					 		+ "  </tbody>\n"
					 		+ "</table>\n"
					 		+ "<script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js\" integrity=\"sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe\" crossorigin=\"anonymous\"></script>\n"
					 		+ "</body>\n"
					 		+ "</html>\n"
					 		+ "");
					 /* out.println(""+ctype);
					 out.println(""+complaint);
					 out.println(rst.getString(1));
					 out.println(rst.getString(2));
//					 out.println("<table border=1>");
			        	out.print("<tr>");
			        
			        	out.print("<td>" +rst.getString(1)+ "</td>");
			        	out.print("<td>" +rst.getString(2)+ "</td>\n");
			        	
			        	out.print(" ");
			        	out.print("</tr>");
			        	out.print("</table>");
			        	out.println("<html>"
								+ "<head>"
								+ "<style type=\"text/css\">\n"
								+ "		.column {\n"
								+ "  float: left;\n"
								+ "  width: 50%;\n"
								+ "}\n"
								+ "\n"
								+ "/* Clear floats after the columns \n"
								+ ".row:after {\n"
								+ "  content: \"\";\n"
								+ "  display: table;\n"
								+ "  clear: both;\n"
								+ "}\n"
								+ "	</style>"
								
								+ "</head>"
								+ "<body>"
								+ "<div class=\"row\"style=\"border: 1px solid black;\">\n"
								+ "  <div class=\"column\"style=\"border: 1px solid black;\"><center><td>" +rst.getString(1)+ "</td></center></div>\n"
								+ "  <div class=\"column\"style=\"border: 1px solid black;\"><center><td>" +rst.getString(2)+ "</td></center></div>\n"
								+ "</div>"
								+ "</body>"
								+ "</html>");
					
					/*out.println("<html>"
							+ "<head>"
							+ "<link href=\\\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css\\\" rel=\\\"stylesheet\\\" integrity=\\\"sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ\\\" crossorigin=\\\"anonymous\\\">"
							
							
							+ "</head>"
							+ "<body>"
							+ "<table>"
							+ "<tbody>"
						    +"<tr>"
						    + "<th>1</th>"
						    + "<td>Mark</td>"
						    + "<td>Otto</td>"
						    + "<td>@mdo</td>"
						    + "</tr>"
						    + "<tr>"
						    + "<th>2</th>"
						    + "<td>Jacob</td>"
						    + "<td>Thornton</td>"
						    + "<td>@fat</td>"
						    + "</tr>"
						    +"</tbody>"
							+ "</table>"
							+ "<script src=\\\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js\\\" integrity=\\\"sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe\\\" crossorigin=\\\"anonymous\\\"></script>"
							+ "</body>"
							+ "</html>");
			        	 int r=rst.getRow();
			     	    data=new String[r][3];
			     	   //  p=new int[r][1];
			     	    rst.first();
			     	    while(rst.next())
			     	    {
			     	    	data[i][0]=rst.getString(1);
			     	    	data[i][1]=rst.getString(2);
			     	    	
			     	    	i++;
			     	    }
			     	    JTable jt=new JTable(data,head);
			     	  
			     	
			     	    
			     	
			     	
			     	}*/
					
				
		 }
		 }
				catch (Exception e) {
					System.out.println("Exception "+e.getMessage());
				}
					
				
		        
				}
}
