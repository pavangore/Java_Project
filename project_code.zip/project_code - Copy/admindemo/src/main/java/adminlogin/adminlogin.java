package adminlogin;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Servlet implementation class adminlogin
 */
public class adminlogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public adminlogin() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 

{
		
		PrintWriter out=response.getWriter();
        Connection con = null;
        response.setContentType("text/html");
    
    
        String uemail=request.getParameter("username");
		String upwd=request.getParameter("password");
		//out.println(""+uemail);
		
    try {
		
		
		Class.forName("com.mysql.jdbc.Driver");
		String connectionURL = "jdbc:mysql://localhost:3306/student?useSSL=false";
		System.out.println("getConnection START");
		
		con = DriverManager.getConnection(connectionURL, "root", "Tanu@123");
        System.out.println(con);
        System.out.println("getConnection END");
        
        PreparedStatement pst = con.prepareStatement("select * from adminlogin where uemail=? and upass=?");
        
        pst.setString(1,uemail);	
		pst.setString(2,upwd);
		
		ResultSet rst=pst.executeQuery("select * from adminlogin");
		while(rst.next())
		{
			//out.println(rst.getString(1));
			//String user=rst.getString(1);
			//String pass=rst.getString(2);
		if((uemail.equals(rst.getString(1)))&&(upwd.equals(rst.getString(2)))) {
			       out.println("<html>");
			       out.println("<head>");
			       out.println("<link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ\" crossorigin=\"anonymous\">");
			       out.println("</head>");
			       out.println("<nav class=\"navbar bg-body-tertiary\">\n"
			       		+ "			       <div class=\"container-fluid\">\n"
			       		+ "			         <form class=\"d-flex\" role=\"search\">\n"
			       		+ "			           <input class=\"form-control me-2\" type=\"search\" placeholder=\"Search\" aria-label=\"Search\">\n"
			       		+ "			           <button class=\"btn btn-outline-success\" type=\"submit\">Search</button>\n"
			       		+ "			         </form>\n"
			       		+ "			       </div>\n"
			       		+ "			     </nav>");
				     
				      out.println("<form method='post' action='http://localhost:8080/admindemo/response' >");
				      out.println(" <div class=\"mx-auto p-2 my-5\" style=\"width: 600px;\"><center><label for=\"floatingInput\" ><h1>You want to see complaints</h1></label></centre><br><center><input type='submit' value='OK' class=\"btn btn-primary btn-lg my-3\"></center></div>");
				      out.println("");
				      out.println("</form>");
				      out.println("<script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js\" integrity=\"sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe\" crossorigin=\"anonymous\"></script>");
				      out.println("</html>");
		}
					
		}
		
		
		//RequestDispatcher dispatcher = request.getRequestDispatcher("registration.jsp");		
       // System.out.println("rowCount "+rowCount);

      }
    catch (Exception e) {
		System.out.println("Exception "+e.getMessage());
	}
    
    
    if(con != null){
        try {
            con.close();
        } catch (SQLException e) {
        	System.out.println(e.getMessage());
            e.printStackTrace();
        }
    }
        
	
	
}
}

