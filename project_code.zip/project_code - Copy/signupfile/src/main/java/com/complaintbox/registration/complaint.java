package com.complaintbox.registration;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Servlet implementation class complaint
 */
public class complaint extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public complaint() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
//	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
Connection con = null;
		
		RequestDispatcher dispatcher=null ;
		PrintWriter pw=response.getWriter();
		
		
		String ctype = request.getParameter("ctype");
		/*String Fees = request.getParameter("Fees");
		String Teaching = request.getParameter("Teaching");
		String Staff = request.getParameter("Staff");
		String Cleaning = request.getParameter("Cleaning");
		String Classroom = request.getParameter("Classroom");
		String Ragging = request.getParameter("Ragging");
		String environment = request.getParameter("environment");
		String Out_side = request.getParameter("Out-side environment");
		String Sports = request.getParameter("Sports");
		String Exam = request.getParameter("Exam");
		String Canteen = request.getParameter("Canteen");
		String Other = request.getParameter("Other");*/
	    String complaint = request.getParameter("message"); 
		  pw.println(""+ctype);
		  pw.println(""+complaint);
		 // pw.println(""+sub);
		  
		  try {
				
				
				Class.forName("com.mysql.jdbc.Driver");
				String connectionURL = "jdbc:mysql://localhost:3306/student?useSSL=false";
				System.out.println("getConnection START");
				
		        con = DriverManager.getConnection(connectionURL, "root", "Tanu@123");
		        System.out.println(con);
		        System.out.println("getConnection END");
		       
		        
		      PreparedStatement pst = con.prepareStatement("insert into complaint(c_type,c_dis) values(?,?)");
				pst.setString(1,ctype);	
				pst.setString(2,complaint);	
				
				
				
				int rowCount=pst.executeUpdate();
				System.out.println("record is inserted");
				 //dispatcher = request.getRequestDispatcher("registration.jsp");
				 dispatcher = request.getRequestDispatcher("subcomp.jsp");
				
		       System.out.println("rowCount "+rowCount);
		        
		        if(rowCount > 0)
		        {
		        	request.setAttribute("status", "success");
		        }
		        else
		        {
		        	request.setAttribute("status", "failed");
		        }
		        
		       dispatcher.forward(request,response);
		    
			}catch (Exception e) {
				System.out.println("Exception "+e.getMessage());
			}
				
			if(con != null){
	            try {
	                con.close();
	            } catch (SQLException e) {
	            	System.out.println(e.getMessage());
	                e.printStackTrace();
	            }
	        }
				
				
				
				
				
				
					
		}
	
	}


