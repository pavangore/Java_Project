package com.complaintbox.registration;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//import com.mysql.cj.Session;

/**
 * Servlet implementation class Login
 */
@WebServlet("/login")

public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
        Connection con = null;
		
		System.out.println("inside doPost");
		
		
		String uemail=request.getParameter("username");
		String upwd=request.getParameter("password");
		//ServletRequest session=null;
		HttpSession session=request.getSession();
		RequestDispatcher dispatcher=null ;
		
		if(uemail==null || uemail.equals("") )
		{
			request.setAttribute("status","invalidEmail");
			
			 dispatcher = request.getRequestDispatcher("login.jsp");
			 dispatcher.forward(request,response);
		}
		
		if(upwd==null || upwd.equals("") )
		{
			request.setAttribute("status","invalidupwd");
			
			 dispatcher = request.getRequestDispatcher("login.jsp");
			 dispatcher.forward(request,response);
		}
		
        try {
			
			
			Class.forName("com.mysql.jdbc.Driver");
			String connectionURL = "jdbc:mysql://localhost:3306/student?useSSL=false";
			System.out.println("getConnection START");
			
			con = DriverManager.getConnection(connectionURL, "root", "Tanu@123");
	        System.out.println(con);
	        System.out.println("getConnection END");
	        
	        PreparedStatement pst = con.prepareStatement("select * from users where uemail=? and upwd=?");
	        
	        pst.setString(1,uemail);	
			pst.setString(2,upwd);
			
			ResultSet rst=pst.executeQuery();
			//RequestDispatcher dispatcher = request.getRequestDispatcher("registration.jsp");		
	       // System.out.println("rowCount "+rowCount);
		
		   if(rst.next())
	        {
	        	//request.setAttribute("status", "success");
	        
	        	
				session.setAttribute("name",rst.getString("uname"));
				
				 dispatcher = request.getRequestDispatcher("index.jsp");
	        
			}
	        else
	        {
	        	request.setAttribute("status", "failed");
	        	 dispatcher = request.getRequestDispatcher("login.jsp");
	        }
	        
		  dispatcher.forward(request,response);
		}catch (Exception e) {
			System.out.println("Exception "+e.getMessage());
		}
        
        
        if(con != null){
            try {
                con.close();
            } catch (SQLException e) {
            	System.out.println(e.getMessage());
                e.printStackTrace();
            }
        }
	        
		
		
	}

	private void forward(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}

	
}

